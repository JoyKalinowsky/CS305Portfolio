package com.snhu.sslserver;
import java.security.Provider;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.owasp.html.PolicyFactory;
import org.owasp.html.Sanitizers;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController {
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
    	String data = "Joy Kalinowsky";

        MessageDigest message = MessageDigest.getInstance("SHA-256");
    	message.update(data.getBytes());  
        byte[] digestedMessage = message.digest();      
       
        String hexMessage = bytesToHex(digestedMessage);
        
        PolicyFactory newPolicy = Sanitizers.FORMATTING.and(Sanitizers.LINKS);
        String safeLine = newPolicy.sanitize("<p>Name: "+ data  + " Checksum Data String: " + hexMessage);
        return safeLine;
    }
    
    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if(hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
